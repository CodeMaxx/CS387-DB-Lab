insert into post values (nextval('postid'), '00128', CURRENT_TIMESTAMP, 'Hi! this is Zhang!!');
insert into post values (nextval('postid'), '00128', CURRENT_TIMESTAMP, 'I live in Mumbai.');
insert into post values (nextval('postid'), '00128', CURRENT_TIMESTAMP, 'I like to sleep and eat');
insert into post values (nextval('postid'), '00128', CURRENT_TIMESTAMP, 'I dont study much');
insert into post values (nextval('postid'), '00128', CURRENT_TIMESTAMP, 'I play a lot of games');


insert into post values (nextval('postid'), '12345', CURRENT_TIMESTAMP, 'Hi! This is Shankar!!');
insert into post values (nextval('postid'), '12345', CURRENT_TIMESTAMP, 'I live in Delhi');
insert into post values (nextval('postid'), '12345', CURRENT_TIMESTAMP, 'I like to play games');
insert into post values (nextval('postid'), '12345', CURRENT_TIMESTAMP, 'I watch a lot of movies');
insert into post values (nextval('postid'), '12345', CURRENT_TIMESTAMP, 'I love to travel');


insert into post values (nextval('postid'), '19991', CURRENT_TIMESTAMP, 'Hi! This is Brandt!!');
insert into post values (nextval('postid'), '19991', CURRENT_TIMESTAMP, 'I live in Bareli');
insert into post values (nextval('postid'), '19991', CURRENT_TIMESTAMP, 'I like to eat pan');
insert into post values (nextval('postid'), '19991', CURRENT_TIMESTAMP, 'I play chess and ludo');
insert into post values (nextval('postid'), '19991', CURRENT_TIMESTAMP, 'I love my country');
insert into post values (nextval('postid'), '19991', CURRENT_TIMESTAMP, 'May be I can become a soldier one day');


insert into post values (nextval('postid'), '23121', CURRENT_TIMESTAMP, 'Hi! This is Chavez!!');
insert into post values (nextval('postid'), '23121', CURRENT_TIMESTAMP, 'I live in Calcutta');
insert into post values (nextval('postid'), '23121', CURRENT_TIMESTAMP, 'I love to eat fish');
insert into post values (nextval('postid'), '23121', CURRENT_TIMESTAMP, 'Sunday is my favrate day');
insert into post values (nextval('postid'), '23121', CURRENT_TIMESTAMP, 'I play football daily');
insert into post values (nextval('postid'), '23121', CURRENT_TIMESTAMP, 'We have the hugli river in my city');
insert into post values (nextval('postid'), '23121', CURRENT_TIMESTAMP, 'Hi! This is Chavez!!');



insert into post values (nextval('postid'), '44553', CURRENT_TIMESTAMP, 'Hi! This is Peltier!!');
insert into post values (nextval('postid'), '44553', CURRENT_TIMESTAMP, 'I live in Patna!');
insert into post values (nextval('postid'), '44553', CURRENT_TIMESTAMP, 'There is so much hot here');
insert into post values (nextval('postid'), '44553', CURRENT_TIMESTAMP, 'I want to study in IIT');
insert into post values (nextval('postid'), '44553', CURRENT_TIMESTAMP, 'Can you help me in this?');
insert into post values (nextval('postid'), '44553', CURRENT_TIMESTAMP, 'One day I may become the PM of India');
insert into post values (nextval('postid'), '44553', CURRENT_TIMESTAMP, 'Watch out your weakness');
insert into post values (nextval('postid'), '44553', CURRENT_TIMESTAMP, 'I am going to America');












